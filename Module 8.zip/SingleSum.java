
// Written by Jeremy Fristoe
// CEN-3024C-17056 Module 8 v1, 11/1/20
// This program generates 200M random numbers between 1 and 10, summing them using a single
// thread. When it completes, it outputs the total sum of all numbers generated, as well as
// the time (in milliseconds) it took to perform the calculations.

package m8v1;

import java.util.Random;

public class SingleSum extends Thread {

	// assigning array-related variables as integer type
    private int[] array;
    private int low;
    private int high;
    private int subtotal;

    // specifying the structure of the array
    public SingleSum(int[] array, int low, int high) {
        this.array = array;
        this.low = low;
        this.high = Math.min(high, array.length);
    }

    // associate the getSubtotal process with the subtotal variable
    public int getSubtotal() {
        return subtotal;
    }

    // setting subtotal variable values
    public void run() {
        subtotal = sum(array, low, high);
    }

    // retrieving array information
    public static int sum(int[] array) {
        return sum(array, 0, array.length);
    }

    // keeping track of array count
    public static int sum(int[] array, int low, int high) {
    	
        // setting total variable as an integer type and initializing it to 0
        int total = 0;

	    // tracking array loops
        for (int i = low; i < high; i++) {
            total += array[i];
        }
        return total;
    }

	public static void main(String[] args) {
		
		// setting randNum as a Random type
	    Random randNum = new Random();

	    // setting the number of elements in the array to 200M
	    int[] array = new int[200000000];

	    // performing calculations
	    for (int i = 0; i < array.length; i++) {
	        array[i] = randNum.nextInt(10) + 1;
	    }

	    // setting start as a long type which will track time in ms
	    long start = System.currentTimeMillis();

	    // grab total sum of array
	    SingleSum.sum(array);
	    
	    // output total sum of array
	    System.out.println("Sum of elements: " + sum(array));
	
	    // output time it took to perform the calculations
	    System.out.println("Time (in ms): " + (System.currentTimeMillis() - start));

	}
	
}