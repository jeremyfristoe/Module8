
// Written by Jeremy Fristoe
// CEN-3024C-17056 Module 8 v1, 11/1/20
// This program generates 200M random numbers between 1 and 10, summing them in parallel
// (i.e., using multiple threads). When it completes, it outputs the total sum of all
// numbers generated, as well as the time (in milliseconds) it took to perform the calculations.

package m8v1;

import java.util.Random;

public class ParallelSum extends Thread {

	// assigning array-related variables as integer type
    private int[] array;
    private int low;
    private int high;
    private int subtotal;

    // specifying the structure of the array
    public ParallelSum(int[] array, int low, int high) {
        this.array = array;
        this.low = low;
        this.high = Math.min(high, array.length);
    }

    // associate the getSubtotal process with the subtotal variable
    public int getSubtotal() {
        return subtotal;
    }

    // setting subtotal variable values
    public void run() {
        subtotal = sum(array, low, high);
    }

    // retrieving array information
    public static int sum(int[] array) {
        return sum(array, 0, array.length);
    }

    // keeping track of array count
    public static int sum(int[] array, int low, int high) {
        int total = 0;

        for (int i = low; i < high; i++) {
            total += array[i];
        }
        return total;
    }

    // keeping track of time count
    public static int parSum(int[] array) {
        return parSum(array, Runtime.getRuntime().availableProcessors());
    }

    public static int parSum(int[] array, int threads) {
        int size = (int) Math.ceil(array.length * 1.0 / threads);

        ParallelSum[] sums = new ParallelSum[threads];

        for (int i = 0; i < threads; i++) {
            sums[i] = new ParallelSum(array, i * size, (i + 1) * size);
            sums[i].start();
        }

        // error handling
        try {
            for (ParallelSum sum : sums) {
                sum.join();
            }
        }
        catch (InterruptedException e) {	
        }

        // setting total variable as an integer type and initializing it to 0
        int total = 0;

        for (ParallelSum sum : sums) {
            total += sum.getSubtotal();
        }
        return total;
    }

	public static void main(String[] args) {
		
		// setting randNum as a Random type
	    Random randNum = new Random();

	    // setting the number of elements in the array to 200M
	    int[] array = new int[200000000];

	    // performing calculations
	    for (int i = 0; i < array.length; i++) {
	        array[i] = randNum.nextInt(10) + 1;
	    }

	    // setting start as a long type which will track time in ms
	    long start = System.currentTimeMillis();

	    // grab total sum of array
	    ParallelSum.parSum(array);
	    
	    // output total sum of array
	    System.out.println("Sum of elements: " + parSum(array));
	    
	    // output time it took to perform the calculations
	    System.out.println("Time (in ms): " + (System.currentTimeMillis() - start));
	}
	
}